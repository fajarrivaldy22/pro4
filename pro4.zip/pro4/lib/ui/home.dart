import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:pro4/utils/firebase_auth.dart';
import 'package:provider/provider.dart';

import 'component/Account/Account.dart';
import 'component/Dahboard/Dashboard.dart';


class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();

}

class _HomePageState extends State<HomePage> {
  int _initialIndex = 0;
  final styleForText = TextStyle(color: Colors.white);
  final List<Widget> _widgetOption = <Widget>[
    DashboardMain(),
    Text("Inbox wid" ),
    Text("News wid"),
    Text("Order wid"),
    AccountMain()
  ];
  static const List<String> _titles = <String>[
    "Dashboard",
    "Inbox",
    "News",
    "Order",
    "Account"
  ];
  void _onItemTapped(int index){
    setState(() {
      _initialIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    return Scaffold(
      
      body: Center(
        child: _widgetOption.elementAt(_initialIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        fixedColor: Colors.amber,
        unselectedItemColor: Colors.grey,
        currentIndex: _initialIndex,
        onTap: _onItemTapped,
        
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.home),title: Text('Home')),
          BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.inbox),title: Text('Inbox')),
          BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.newspaper),title: Text('News')),
          BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.list),title: Text('Order')),
          BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.user),title: Text('Account')),
        ]
      ),
    );
  }
}





