import 'package:flutter/cupertino.dart';

class User with ChangeNotifier{
  
}